bash prune_doc_index_all.sh $1
bash prune_quantile_all.sh $1
